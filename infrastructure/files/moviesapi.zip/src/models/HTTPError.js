"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HTTPError = void 0;
class HTTPError {
    constructor(message, status = 500, additionalInfo = {}) {
        this.message = message;
        this.status = status;
        this.additionalInfo = additionalInfo;
    }
}
exports.HTTPError = HTTPError;
