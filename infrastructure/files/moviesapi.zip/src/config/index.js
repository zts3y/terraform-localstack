"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    db: ""
};
exports.default = config;
