"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPError_1 = require("./../models/HTTPError");
/**
 * Custom error handler to standardize error objects returned to
 * the client
 *
 * @param err Error caught by Express.js
 * @param req Request object provided by Express
 * @param res Response object provided by Express
 * @param next NextFunction function provided by Express
 */
function handleError(err, req, res, next) {
    let customError = err;
    if (!(err instanceof HTTPError_1.HTTPError)) {
        customError = new HTTPError_1.HTTPError('An unspecified error has occurred.');
    }
    res.status(customError.status).send(customError);
}
;
exports.default = handleError;
